import React, {Fragment} from "react";
import {Helmet} from "react-helmet";

import {Route, Switch} from "react-router-dom";

import routes from "../routes";
import Login from "../containers/login/Login";


const RootView: React.StatelessComponent<{}> = () => (
    <Fragment>
        <Helmet
            titleTemplate='Test Assignment - %s'
            defaultTitle='Unknown page'
        />
        <main>
            <Switch>
                <Route path={routes.ROOT} component={Login}/>
            </Switch>
        </main>
    </Fragment>
);

export default RootView;
