import React, {FormEvent, Fragment} from "react";
import "./Login.scss";

import {LoginFormProps, LoginFormState} from "./types/LoginForm";
import {connect} from "react-redux";
import {AppState} from "../../reducers";
import Helmet from "react-helmet";
import {inputChange, submitRecovery, toggleModal, toggleModal2, toggleShowPass, tryLogin} from "./actions/actions";
import {Modal} from "../login_modal/Modal";


export class Login extends React.Component<LoginFormProps, LoginFormState> {
    handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        this.props.onSubmit(this.props.user, this.props.pass);
    };

    render() {
        //TODO: do we need placeholders for user/pass input ?
        return (
            <Fragment>
                <Helmet>
                    <title>Login Page</title>
                </Helmet>
                <Modal show={this.props.modal} title={"Password Reset"} close={this.props.triggerModal}>
                    <div className="padding">
                        Please enter the email address associated with your globaledit account to reset ypur password
                        <label htmlFor="email" className="modal-hint">Email Adress</label>
                        <input name="username"
                               type="text"
                               className="form-control white"
                               placeholder="Enter your email"
                               onChange={this.props.onChange}
                               value={this.props.user}
                        />
                    </div>
                    <div className="modal-buttons padding">
                        <button type="submit" className="btn btn-primary" onClick={this.props.submitForgotPwd}>Submit
                        </button>
                        <button type="submit" className="btn btn-primary grey right"
                                onClick={this.props.triggerModal}>Cancel
                        </button>
                    </div>
                </Modal>
                <Modal show={this.props.modal2} title={"Email Sent"} close={this.props.triggerModal2}>
                    <div className="padding">
                        Thank you, instructions to reset your password have been e-mailed to the address you provided!
                    </div>
                </Modal>
                <div className="login padding">
                    <h1>Welcome</h1>
                    <p>Please sign in to continue</p>
                    <hr/>
                    <img src={require("../../static/logo-ge-light.svg")} alt="" id="logo"/>
                    <form onSubmit={this.handleSubmit}>
                        <label htmlFor="username">Username</label>
                        <input name="username"
                               type="text"
                               className="form-control"
                               placeholder="Enter your email"
                               onChange={this.props.onChange}
                        />

                        <label htmlFor="password">Password</label>
                        <input
                            name="password"
                            type={this.props.showPass ? "text" : "password"}
                            className="form-control"
                            placeholder="Enter your password"
                            onChange={this.props.onChange}
                            value={this.props.pass}
                        />

                        <button type="submit" className="btn btn-primary">
                            Sign in
                        </button>
                        <button type="button" onClick={this.props.triggerModal}
                                className="btn btn-link btn-sm right">Forgot password?
                        </button>
                        <a className="inputLink"
                           onClick={this.props.togglePass}>{this.props.showPass ? "Hide" : "Show"}</a>
                        <hr className="desktop"/>
                        <div className="half left desktop">
                            <h1>LATEST BLOG POST</h1>
                            <p>October 15, 2018</p>
                            <p>Create Efficiency with a<br/>
                                Creative Asset Management<br/>
                                Platform</p>
                        </div>
                        <div className="half right desktop">
                            <h1>RECENT TWEET</h1>
                            <p>April 25, 2018</p>
                            <p>#HenryStewartEvents are<br/>
                                bringing their #CreativeOps<br/>
                                Show to NYC for the third...</p>
                        </div>
                    </form>
                </div>
            </Fragment>
        );
    }

}

const mapStateToProps = (state: AppState) => {
    return state.login;
};

const mapDispatchToProps = {
    onChange: inputChange,
    onSubmit: tryLogin,
    triggerModal: toggleModal,
    triggerModal2: toggleModal2,
    submitForgotPwd: submitRecovery,
    togglePass: toggleShowPass,
};

export default connect(mapStateToProps, mapDispatchToProps)(Login);
