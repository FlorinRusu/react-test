import {LoginFormState} from "../types/LoginForm";
import {loginConstants} from "../constants";
import {ILoginActions} from "../actions/actions";

export function loginReducer(state: LoginFormState, action: ILoginActions): LoginFormState {
    //TODO: no instructions given if any visual effects needed on submit, on login fail and on login ok

    switch (action.type) {
        case loginConstants.INPUT_CHANGE:
            if (action.name === "username") {
                return {
                    ...state,
                    user: action.value
                };
            } else {
                return {
                    ...state,
                    pass: action.value
                };
            }
        case loginConstants.LOGIN_SUCCESS:
            return {
                ...state,
                role: action.role
            };
        case loginConstants.LOGIN_FAILURE:
            return {
                ...state,
                user: "",
                pass: "",
            };
        case loginConstants.LOGIN_REQUEST:
            return {
                ...state,
            };
        case loginConstants.LOGOUT:
            return {
                ...state,
                role: "guest"
            };
        case loginConstants.TOGGLE_MODAL:
            return {
                ...state,
                modal: !state.modal,
            };
        case loginConstants.TOGGLE_MODAL2:
            return {
                ...state,
                modal2: !state.modal2,
            };
        case loginConstants.TOGGLE_PASSWORD:
            return {
                ...state,
                showPass: !state.showPass,
            };

        default:
            return state;

    }
}
