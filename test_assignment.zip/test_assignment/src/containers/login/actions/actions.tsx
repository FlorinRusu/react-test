import {Action, Dispatch} from "redux";
import {loginConstants} from "../constants"
import {ChangeEvent} from "react";

//define action interfaces
export interface IAuthenticate extends Action {
    type: loginConstants.LOGIN_REQUEST,
}

export interface IInputChange extends Action {
    type: loginConstants.INPUT_CHANGE,
    name: string,
    value: string
}


export interface IAuthOK extends Action {
    type: loginConstants.LOGIN_SUCCESS,
    role: string
}

export interface ILogout extends Action {
    type: loginConstants.LOGOUT,
}

export interface IToggleModal extends Action {
    type: loginConstants.TOGGLE_MODAL,
}

export interface IToggleModal2 extends Action {
    type: loginConstants.TOGGLE_MODAL2,
}

export interface ITogglePassword extends Action {
    type: loginConstants.TOGGLE_PASSWORD,
}


export interface IAuthError extends Action {
    type: loginConstants.LOGIN_FAILURE,
    errorMessage: string
}


function dispatchAuthRequest(): IAuthenticate {
    return {
        type: loginConstants.LOGIN_REQUEST,
    };
}

function dispatchAuthOK(role: string): IAuthOK {
    return {
        type: loginConstants.LOGIN_SUCCESS,
        role
    };
}

function dispatchAuthFail(e: Error): IAuthError {
    return {
        type: loginConstants.LOGIN_FAILURE,
        errorMessage: e.message
    };
}

const dispathcInputChange = (input: any): IInputChange => {
    return {
        type: loginConstants.INPUT_CHANGE,
        name: input.name,
        value: input.value
    };
};

function dispatchToggleModal(): IToggleModal {
    return {
        type: loginConstants.TOGGLE_MODAL,
    };
}

function dispatchToggleModal2(): IToggleModal2 {
    return {
        type: loginConstants.TOGGLE_MODAL2,
    };
}

function dispatchToggleShowPass(): ITogglePassword {
    return {
        type: loginConstants.TOGGLE_PASSWORD,
    };
}

export type ILoginActions = IAuthenticate | IAuthError | IAuthOK | IInputChange | ILogout | IToggleModal
    | IToggleModal2 | ITogglePassword;

export const inputChange = (e: ChangeEvent) => {
    return (dispatch: Dispatch) => dispatch(dispathcInputChange(e.target));
};

export function toggleModal() {
    return (dispatch: Dispatch) => dispatch(dispatchToggleModal());
}

export function toggleShowPass() {
    return (dispatch: Dispatch) => dispatch(dispatchToggleShowPass());
}

export function toggleModal2() {
    return (dispatch: Dispatch) => dispatch(dispatchToggleModal2());
}

export function submitRecovery() {
    return (dispatch: Dispatch) => {
        //TODO: send email to backend here
        dispatch(dispatchToggleModal());
        dispatch(dispatchToggleModal2());
    }
}


export function tryLogin(user: string, pass: string) {
    return (dispatch: Dispatch) => {
        dispatch(dispatchAuthRequest());
        fetch("/", {
            method: "post",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                "user": user,
                "pass": pass,
            })
        })
            .then(res => res.json())
            .then(res => {
                if (res.error) {
                    throw(res.error);
                }
                dispatch(dispatchAuthOK(res.role));
                return res.products;
            })
            .catch(error => {
                dispatch(dispatchAuthFail(error));
            })
    }
}
