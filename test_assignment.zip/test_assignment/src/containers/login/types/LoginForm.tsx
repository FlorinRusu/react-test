import {ChangeEvent} from "react";

export interface LoginFormState {
    submitted?: boolean;
    user: string;
    pass: string;
    role: string;
    modal: boolean;
    modal2: boolean;
    showPass: boolean;
}

export interface LoginFormProps extends LoginFormState {
    onChange: (e: ChangeEvent) => void;
    onSubmit: (user: string, pass: string) => void;
    triggerModal: () => void;
    triggerModal2: () => void;
    submitForgotPwd: () => void;
    togglePass: () => void;
}

export function defaultLoginFormState(): LoginFormState {
    return {submitted: false, user: "", pass: "", role: "guest", modal: false, modal2: false, showPass: false}
}
