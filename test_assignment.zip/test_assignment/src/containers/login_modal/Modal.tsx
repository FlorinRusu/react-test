import React from "react";
import "./Modal.scss";
import {faTimesCircle} from "@fortawesome/free-solid-svg-icons"
import {ModalProps} from "./types/Modal";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome"

export const Modal: React.FunctionComponent<ModalProps> = (props: ModalProps) => {
    return (
        <div className={"modal " + (props.show ? "show" : "hide")}>
            <div className="title">
                {props.title}
                <button onClick={props.close} className="modal_icon">
                    <FontAwesomeIcon icon={faTimesCircle} size="lg"/>
                </button>
            </div>
            {props.children}
        </div>
    );
};

