import React from "react";
import ReactDOM from "react-dom";
import Modal from "./Modal";

it("renders without crashing", () => {
    const div = document.createElement("div");
    // @ts-ignore
    ReactDOM.render(<Modal></Modal>, div);
    ReactDOM.unmountComponentAtNode(div);
});
