import {ReactNode} from "react";

export interface ModalProps {
    children: ReactNode;
    show?: boolean;
    title: string;
    close: () => void;
}
