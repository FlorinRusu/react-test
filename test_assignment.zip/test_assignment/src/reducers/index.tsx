import {defaultLoginFormState, LoginFormState} from "../containers/login/types/LoginForm";
import {Action} from "redux";
import {loginReducer} from "../containers/login/reducers";


export interface AppState {
    login: LoginFormState;
}


export function defaultState() {
    return {
        login: defaultLoginFormState(),
    };
}


export function mainReducer(state: AppState = defaultState(), action: Action) {
    return {
        login: loginReducer(state.login, action),
    };
}
