export const ROOT_NODE = document.getElementById("root") || "";
export const PROD_ENV = process.env.NODE_ENV === "production";
